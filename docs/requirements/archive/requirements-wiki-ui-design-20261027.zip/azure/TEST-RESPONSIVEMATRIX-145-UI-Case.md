# TEST-RESPONSIVEMATRIX-145 - Minimum width, orientation and zoom preservation

Linked specification for the matching authoritative QBrain TEST record. Persistence is reported by [receipt.json](../receipt.json); this documentation run executed no application tests.

| Field | Specification |
| --- | --- |
| Objective | Verify Minimum width, orientation and zoom preservation. |
| QBrain reference/scope | `TEST-RESPONSIVEMATRIX-145`; Word Pairs / `PROD-WORDPAIRS`; workspace `/home/sharpninja/github/WordGame/.mcpServer/wordpairs`; layer `layer-1` |
| Source revision | Original designs at `3273c121de6517aec34503d8c769b0159e9e52df`; exact dirty prose/decision hashes in [sources.json](../sources.json). New UI-DEC decisions derive from the operator instruction to fill gaps. |
| Source links | [decisions.md](../decisions.md) |
| Frame/element identifiers | GAP-FLOW-RESPONSIVEMATRIX, GAP-TRANS-RESPONSIVEMATRIX-01, GAP-TRANS-RESPONSIVEMATRIX-02; exact SVG anchors are listed in [coverage.md](../coverage.md) |
| FR/TR → specific AC references | `TR-UI-RESPONSIVEMATRIX-040#UI-RESP-01`; `TR-UI-RESPONSIVEMATRIX-040#UI-RESP-02`; `TR-UI-RESPONSIVEMATRIX-040#UI-RESP-03` |
| Priority | high |
| Platform/viewport | Phone Chromium/Android and Safari/iPhone where applicable; project matrix320x568,390x844,844x390;1280px at400%zoom and200%text enlargement. OS-native installation is a separate physical-device dependency. |
| Preconditions/roles | An active round and each form/staff screen can be opened with a populated scorecard and safe in-tab draft. |
| Test data | 320x568,390x844,844x390;1280px at400%zoom;200%text enlargement; draft Space. |
| Synchronization | Await the explicit observable conditions and source-defined deadlines below; no fixed sleeps. Harness timeouts do not create a product response-time SLA. |
| Cleanup | Close case-owned contexts and reset only isolated fixture accounts, rooms or content, including after failure. Preserve shared catalog and real profile data. |
| Automation readiness | Ready to implement automation against isolated seeded UI fixtures after the specified application behavior exists; not run. |
| Basis | Specified by cited designs/QBrain; new gap behavior is specified by UI-DEC-01..08. Synthetic fixture identities/data are test configurations. |
| Execution | Not run here. Existing historical status/evidence remains unchanged; new obligations remain pending/unsatisfied. |

## Ordered actions and observable results

| Step | Action / condition | Observable expected result |
| --- | --- | --- |
| 1 | Visit each screen at each specified viewport and enlargement configuration. | Required text, hint, score fields and controls remain reachable without horizontal page scrolling or clipping; zoom is enabled. |
| 2 | Rotate portrait/landscape while editing Space and while observing the active round. | Draft and authorized room state remain; stacked score layout retains fields; keyboard/touch actions still work. |

## Scenario

```gherkin
Feature: Minimum width, orientation and zoom preservation
  Scenario: TEST-RESPONSIVEMATRIX-145 design verification
    Given An active round and each form/staff screen can be opened with a populated scorecard and safe in-tab draft.
    And the fixture data is 320x568,390x844,844x390;1280px at400%zoom;200%text enlargement; draft Space.
    When Visit each screen at each specified viewport and enlargement configuration.
    Then Required text, hint, score fields and controls remain reachable without horizontal page scrolling or clipping; zoom is enabled.
    When Rotate portrait/landscape while editing Space and while observing the active round.
    Then Draft and authorized room state remain; stacked score layout retains fields; keyboard/touch actions still work.
```

## Boundaries

New specified behavior from operator-directed gap resolution; not implemented or executed by this documentation workflow.

Criterion references identify intended verification. Non-UI transaction, distribution, release/deployment and native OS guarantees retain separate technical/operational tests; this document is not a claim that a compound criterion passed.
