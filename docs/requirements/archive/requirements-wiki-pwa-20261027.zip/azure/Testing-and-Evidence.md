# Testing and evidence

Run commands from the repository root after `npm ci`. The default unit suite uses injected ports and local fixtures. Database and browser suites are separate commands, with their boundaries disclosed below.

| Command | Verification |
|---|---|
| `npm test` | Domain, application, transport, architecture, acceptance-contract and temporary source-archive tests selected by `vitest.config.ts` |
| `npm run typecheck` | TypeScript without emitting application files |
| `npm run lint` | Biome checks for `src` and `tests/architecture`; check other changed test files explicitly with `npm exec biome -- check <paths>` |
| `pwsh -NoProfile -NonInteractive -File tests/integration/run-phase1.ps1` | Disposable PostgreSQL, all migrations, SQL contracts, browser-role denial, final-seat races and every non-Realtime integration file |
| `npm run test:admin` | Same disposable SQL setup plus the focused administration PostgreSQL suite |
| `npm run test:multiplayer` | Same disposable SQL setup plus eight-round games at every size from 2 through 25 players |
| `pwsh -NoProfile -NonInteractive -File tests/integration/run-phase1.ps1 -Realtime` | PostgreSQL verification followed by actual Realtime integration using disposable containers |
| `npm exec playwright -- test --config playwright.phase6.config.ts` | All current phase 2–6 browser journeys, including administration |
| `npm run build` | Local Next.js production compilation and route generation |

The integration runner requires Docker and PowerShell 7. It binds ephemeral database ports to loopback, owns its disposable containers by exact ID and removes them in `finally`. It does not reuse the running game's database. Do not combine the focused `-Administration` and `-Multiplayer` switches; use the unfiltered runner for both suites together.

The browser config starts a development server at `http://127.0.0.1:3100`, uses one worker and can select an existing Chromium executable through `WORDPAIRS_BROWSER_PATH`. Install the matching Playwright Chromium with `npm exec playwright -- install chromium` when using the bundled browser. Stop another Next.js server using this checkout before browser/build work; development and production compilation share `.next`. Run browser verification and production builds sequentially.

## Host-specific browser scratch space

The Phase 6 host exhausted `/tmp` shared-memory quota during Chromium verification. On that host use a fresh, short directory on the workspace disk and remove only that owned directory after the browser exits. The recorded PowerShell pattern is:

```powershell
$env:WORDPAIRS_BROWSER_PATH = '/usr/bin/chromium'
$browserScratch = & mktemp -d '/home/sharpninja/github/WordGame/.wp-XXXXXX'
$env:TMPDIR = $browserScratch
try {
    & npm exec playwright -- test --config playwright.phase6.config.ts
    $testExit = $LASTEXITCODE
} finally {
    Remove-Item -LiteralPath $browserScratch -Recurse -Force -ErrorAction SilentlyContinue
}
exit $testExit
```

This is a host-specific workaround; choose an adequately provisioned short writable scratch path on another machine. The underlying diagnosis and prior failed runs remain in [Phase 6 evidence](phase6_execution.md).

## Verified administration candidate, 27 October 2026

| Evidence | Result |
|---|---|
| Default suite | 502/502 tests, 42 files |
| Full PostgreSQL suite | 66/66 tests, 10 files, plus SQL checks |
| Focused administration PostgreSQL | 8/8 tests |
| Full browser suite | 31/31 journeys |
| Administration browser journeys against the production build | 5/5 journeys |
| Independent hostile review focused suite | 18/18 tests, 5 files |
| Typecheck, lint and production build | Passed |

The multiplayer suite contributes 24 database games, 324 player participations and 2,592 accepted round solves. It checks complete eight-round play, all hint/scoring stages, concurrent conflicts/retries, final standings and exactly-once profile awards. The first combined PostgreSQL run passed 65/66 but hit a 60-second fixture timeout at 25 players while the host was busy. Increasing that fixture's wall-clock budget to 120 seconds retained its assertions; the clean complete rerun passed 66/66. The failure and rerun completion records are retained.

The [hostile review receipt](admin_acl_review_receipt.json) identifies the exact [189-file snapshot](admin_acl_review_manifest.json), independently checked source hashes, resolved findings and evidence qualifications. Approval was 99/100 in accuracy and completeness with no unresolved material finding. [Completion logs](evidence/admin/) preserve the unit/build results, the first database failure, the passing database rerun and the production browser result. Later documentation maintenance does not alter that historical snapshot or claim review of subsequently edited documentation.

## Phone PWA verification

Run `npm test -- tests/web/pwa-manifest.test.ts tests/web/pwa-support.test.ts tests/web/pwa-worker.test.ts` for manifest/icon contracts, install-event/standalone lifecycle and service-worker privacy/update controls. These tests were authored first and failed 13/13 before implementation. Maskable artwork is checked against the circular safe area; icons are decoded to confirm dimensions and opacity.

Run `npm run build`, then `npx playwright test --config=playwright.pwa.config.ts`. This configuration starts a production server on loopback port 3200 and runs all existing browser journeys plus the real worker, CacheStorage allowlist, offline navigation/API/mutations, reconnection, parsed manifest and Chromium installability diagnostics. It also checks mobile layout, iPhone guidance and synthetic install events. Add `pwa.spec.ts` to run only the four PWA journeys. Use `WORDPAIRS_BROWSER_PATH` and a short writable `TMPDIR` as described above when needed. Evidence is under `docs/evidence/pwa/`.

Current PWA extension results: 14/14 focused contracts, 516/516 full unit/contract regression tests in 45 files, 35/35 production browser journeys, no lint warnings and a successful production build. These full suites were rerun after a hostile-review correction for safe-area persistence in standalone mode and installation-panel padding under the complete CSS cascade. The real installability diagnostic uses a disposable regular profile; the initial default incognito check correctly reported `in-incognito`, and its failure log is retained. No browser error is filtered out of the passing result.

The initial production run exposed a test assumption about the legacy `apple-mobile-web-app-capable` name. Installed Next.js 16.4.3's `appleWebApp.capable` emits `mobile-web-app-capable`; the test now verifies that actual framework metadata plus Apple title/touch icon and standalone manifest. This corrects the metadata expectation, not a weakened installability or private-cache assertion. The initial failure log is retained.

Browser prompt events are synthetic lifecycle checks, iPhone user-agent screenshots run in Chromium, and Chromium installability diagnostics verify browser prerequisites. None proves that a physical phone installed or relaunched the app. Actual Android/iPhone installation at a hosted HTTPS origin remains operational verification. Multiplayer still requires network access; no private game data is stored for offline play.

## Evidence boundaries

Administration browser journeys use HTTP fixtures. The catalog journey invokes the real content application/domain code with an in-memory transaction port; it does not prove PostgreSQL authorization. Separate real PostgreSQL tests cover trusted environment bootstrap, actual route handlers, role authorization, revocation races, final-administrator protection, canonical retries, audit rollback, immutable catalog versions and the 4096-version ceiling. Those route tests substitute only the test database TLS connection factory for disposable plaintext PostgreSQL; production TLS verification remains enabled.

Phone captures received independent agent visual inspection, alongside automated interaction/layout checks. Human feedback is optional and no personal human sign-off is claimed. Historical Phase 6 source-bound AC mapping remains in [the acceptance inventory](ac_test_inventory.md), [gap analysis](ac_gap_analysis.md) and [execution record](phase6_execution.md). Its four actual Realtime tests describe that historical run; the administration extension did not claim a new Realtime run. Database and transport evidence supplements the AC contract evidence. Hosted deployment and live provider/account validation remain Phase 7 work.
