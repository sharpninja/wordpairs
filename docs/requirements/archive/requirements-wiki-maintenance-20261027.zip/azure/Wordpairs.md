# Wordpairs

Wordpairs is a real-time word-association game. Its [requirements](docs/word_association_game_requirements.md), [AC gap analysis](docs/ac_gap_analysis.md), [test execution receipt](docs/test_execution_receipt.jsonl), [planned AC test inventory](docs/ac_test_inventory.md), [repo review receipt](docs/repo_review_receipt.jsonl), [implementation plan](docs/implementation_plan.md), [Phase 1A execution record](docs/phase1a_execution.md), [Phase 0–6 hostile-validation goal](docs/goal_hv_agreement_through_phase_6.md), [Phase 0 execution tracker](docs/implementation_phase0_execution.md), [Phase 0 interface and data contracts](docs/phase0_interface_and_data_contracts.md), [Phase 0 approval receipt](docs/phase0_approval_receipt.jsonl), [Phase 0 refresh review receipt](docs/phase0_refresh_hostile_review_receipt.jsonl), [implementation kickoff review receipt](docs/implementation_kickoff_receipt.jsonl), [approved architecture decision record](docs/architecture_decision_record.md), [architecture design and FR/TR traceability](docs/architecture_design.md), [architecture patterns](docs/architecture_patterns.md), [deployment plan](docs/deployment_plan.md), [moderation plan](docs/moderation_plan.md), and rendered diagrams are in `docs/`.

## Project status

Phases 0–6 completed implementation and independent phase-exit review, including multiplayer gameplay, moderation and final acceptance. Historical evidence remains in the [Phase 6 execution record](docs/phase6_execution.md). The [administration and ACL extension](docs/admin_acl_design.md) adds dedicated moderation, word/hint editing and role-management pages, with its own validation. Hosted deployment remains Phase 7; a locally running app is not a hosted release.

## Local setup and validation

The application uses Next.js 16.4.3, React 19.3.1 and TypeScript 6.0.3, pinned in `package.json` and `package-lock.json`. Install dependencies with `npm ci`, configure the server environment and a migrated TLS-enabled database as described in [local development](docs/local_development.md), then run `npm run dev -- --hostname 127.0.0.1 --port 3000`. Open the exact origin configured in `WORDPAIRS_ORIGIN`.

The [testing guide](docs/testing.md) lists unit, PostgreSQL, multiplayer, administration, Realtime and browser commands and their evidence boundaries. The administration candidate passed 502 unit/contract tests, 66 PostgreSQL tests and 31 browser journeys, plus the production build. Its [independent hostile review](docs/admin_acl_review_receipt.json) approved the recorded [189-file snapshot](docs/admin_acl_review_manifest.json) at 99/100 for accuracy and completeness with no unresolved findings. This documentation refresh follows that snapshot and does not relabel it as a review of later bytes.

The [wiki manifest](docs/wiki.yaml) indexes current guides and historical execution records. MCP trust and logging were restored by registering this repository and correcting the service configuration file's ACL mask. The [maintenance receipt](docs/maintenance_receipt.json) records the recovery, triage reports and requirements-export outcome.

## Administration

The administration pages are `/admin` (moderation queue and curation), `/admin/words` (word pairs, answers, alternatives and three hints), and `/admin/users` (role assignment and audit history). Moderators manage content; senior moderators also resolve independent appeals; administrators additionally manage user access.

Set the server-only `WORDPAIRS_ADMIN_PROFILE_IDS` variable to comma-separated existing profile IDs, then restart the server. Find your ID under **Profile details** in the signed-in/guest profile panel. Configured administrators cannot have that authority revoked in the UI. There is no default admin account, password or public bootstrap endpoint. Use a durable signed-in profile for operational access. Apply `src/infrastructure/migrations/010_access_control.sql` to an existing database before using user administration; new test databases apply it automatically.

Edits create immutable pair versions for future rounds; current games retain their original words and hints. See the [admin/ACL design](docs/admin_acl_design.md). Run the focused PostgreSQL checks with `npm run test:admin`.

## Multiplayer integration tests

Run `npm run test:multiplayer` with Docker, PowerShell 7, and installed npm dependencies. The runner creates a disposable, loopback-only PostgreSQL container, applies every migration, and removes the container in `finally`. It does not use the running game's database.

The suite plays eight-round games at every size from 2 through 25 players (24 games, 324 player participations). It exercises real identity, room, lobby, match, and PostgreSQL services, including simultaneous answer conflicts and retries, all hint/scoring stages, shared final standings, and exactly-once profile awards. Time and random draws are controlled; browser UI and Realtime transport remain covered by their separate suites. The full `tests/integration/run-phase1.ps1` run also includes this suite.

## License

The game is intended to use GNU GPL version 2 only (`GPL-2.0-only`). See [`LICENSE`](LICENSE).

## Deployment target

The application target is Vercel from `sharpninja/wordpairs`. Coding Phases 1–6 precede all Phase 7 deployment and release work.
